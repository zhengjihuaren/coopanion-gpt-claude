figure.json、figure.js 与 model.json 的使用说明。

# Claude 娘

在 Coopanion「装扮 → 形象 → 导入」中选择 `gpt-claude-v1.0.0.zip`，确认导入后选择「Claude 娘」。
也可以导入本文件所在的文件夹。

形象包 ID：`gpt-claude`。版本：`1.0.0`。格式：`manifest: 2`、`api: 2`。

按 Coopanion v0.1.24 的格式制作，核对的上游提交为 `91293b3e31b94397a8f2eb79dffec40f4c6d8817`。

## 出处与版权（请先看这里）

- 形象来自**网络**，非本人原创，也**没有拿到授权**。
- **禁止商用**：不得用于任何形式的商业用途 —— 售卖、内置进收费产品、
  广告或宣传素材、带货、付费素材包等，一律不行。
- 这是**自己玩、给大家一起玩**的分享，个人使用、转给朋友玩都可以。
- 请勿改动后声称原创；转载请注明来源。

## 动作与表情

19 种表情：平静、开心、眨眼、喜欢、害羞、惊讶、生气、难过、犯困、思考、得意、嘟嘴、
担心、认真、慌张、害怕、期待、大哭、疑惑。

18 种动作：站起、跳、小跳、张望、转身、点头、摇头、转圈、坐下、睡觉、晕、走走、跑、
招手、鞠躬、发抖、扑腾、跳舞。

支持光标视线、自然眨眼、说话口型、倾听、思考、拎起与抛落。头发、呆毛、刘海、手臂、
裙摆、双腿、眉毛分别绑定；坐姿使用 PSD 里独立的坐姿分片。

## 素材

原画与 `seethrough_output.psd` 由用户提供。透明分片从 PSD 按图层导出，放在 `tex/`；
表情件（嘴、眼、睫毛）放在 `feat/`，其余表情在运行时绘制。声音和身体运动使用应用提供的
kit，包内不附带音频。此包只有原画配色和服装。

## 文件

- `figure.json`：名称、版本、入口与动作词表。
- `figure.js`：分片变形、表情与运行时入口。
- `model.json`：分片坐标和转动枢轴，保留 PSD 的 1024 × 1024 坐标。
- `tex/`：透明分片。
- `feat/`：表情分片。
- `thumbs/gpt-claude.png`：装扮页缩略图。

## 核对来源

- [Coopanion v0.1.24](https://github.com/Pal-AI-Lab/Coopanion/releases/tag/v0.1.24)
- [形象包接口](https://github.com/Pal-AI-Lab/Coopanion/blob/91293b3e31b94397a8f2eb79dffec40f4c6d8817/packages/cortico-world-desktop-pet/README.md#形象包)
- [形象包制作说明](https://github.com/Pal-AI-Lab/Coopanion/blob/91293b3e31b94397a8f2eb79dffec40f4c6d8817/packages/cortico-world-desktop-pet/examples/whale/README.md#写一个形象包)
